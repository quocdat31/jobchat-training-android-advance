package com.example.androidadvance2

import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.util.Log
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import androidx.annotation.RequiresApi


class MyMediaPlayer(var mediaPlayer: MediaPlayer?,
                    var context: Context,
                    var uri: Uri,
                    var seekBar: SeekBar,
                    var imageView: ImageView
                    ):
    Service(),
    MediaPlayer.OnCompletionListener,
    Runnable {

    override fun onBind(intent: Intent?): IBinder? {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun onCompletion(mp: MediaPlayer?) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        mediaPlayer?.isLooping = true
        mediaPlayer?.start()
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        mediaPlayer?.stop()
    }


    @RequiresApi(Build.VERSION_CODES.N)
    fun play(textView: TextView) {

            var myThread = MyThread(mediaPlayer, seekBar)
            var handler = Handler()
            var runnable = Runnable {
                mediaPlayer?.apply {
                    setAudioStreamType(AudioManager.STREAM_MUSIC)
                    setDataSource(context, uri)
                    prepare() // might take long! (for buffering, etc)
                    start()
                    seekBar.progress = currentPosition
                    seekBar.max = duration
                    textView.text = timeFormat(duration)
                }
            }

            imageView.setImageResource(R.drawable.ic_pause_black_24dp)
            handler.postDelayed(runnable,1000)
            myThread.start()

    }

    fun pause() {
        if (mediaPlayer != null)
            mediaPlayer?.pause()
    }

    fun stop() {
        if (mediaPlayer != null) {
            mediaPlayer?.release()
            mediaPlayer = null
        }
    }

    fun seekTo(msec: Int) {
        mediaPlayer?.seekTo(msec)
    }

    fun getDuration(): Int? {
        return mediaPlayer?.duration
    }

    override fun run() {

    }
}

class MyThread(var mediaPlayer: MediaPlayer?, var seekBar: SeekBar) : Thread() {
    override fun run() {
        while (true) {
            try {
                sleep(1000)
            } catch (e: InterruptedException) {
                e.printStackTrace()
            }
            if (mediaPlayer != null) {
                seekBar.post(Runnable { seekBar.progress = mediaPlayer!!.currentPosition })
            }
        }
    }
}