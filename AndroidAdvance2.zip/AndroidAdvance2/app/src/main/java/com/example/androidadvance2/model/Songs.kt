package com.example.androidadvance2.model

import android.net.Uri

data class Songs(var title: String, var artist: String, var uri: Uri)